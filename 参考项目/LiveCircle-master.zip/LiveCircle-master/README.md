# LiveCircle
Live圈 边学边做，不断完善

**新闻模块**

1.Toolbar+NavigationView+DrawerLayout 并实现沉浸式状态栏

2.RecycleView+GridView嵌套 实现多布局格式

3.SwipeRefreshLayout+自定义模式 实现上拉刷新 下拉加载更多（有缺陷，没有下拉加载更多的提示，后期会尝试通过自定义RecycleView实现上拉刷新 下拉加载更多）

4.RecycleView+ItemTouchHelper.Callback 实现Item的拖拽及滑动操作 实现新闻频道管理页面

**图片模块**

IRecyleView开源自定义控件，实现上拉刷新 下拉加载更多

Fragment+ViewPager+TabLayout懒加载机制的实现  
![](http://upload-images.jianshu.io/upload_images/3985563-9fd54f74ee60ed5c.png?imageMogr2/auto-orient/strip%7CimageView2/2)
![](http://upload-images.jianshu.io/upload_images/3985563-6a141a248f2f279a.png?imageMogr2/auto-orient/strip%7CimageView2/2)
![](http://upload-images.jianshu.io/upload_images/3985563-23d52fd7c7e3fad2.png?imageMogr2/auto-orient/strip%7CimageView2/2)
