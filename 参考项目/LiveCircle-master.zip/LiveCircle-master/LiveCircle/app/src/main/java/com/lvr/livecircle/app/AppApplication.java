package com.lvr.livecircle.app;

import com.lvr.livecircle.base.BaseApplication;

/**
 * APPLICATION
 */
public class AppApplication extends BaseApplication {
    @Override
    public void onCreate() {
        super.onCreate();

    }
}
