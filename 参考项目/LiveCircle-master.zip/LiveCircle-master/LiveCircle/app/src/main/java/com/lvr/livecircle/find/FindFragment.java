package com.lvr.livecircle.find;

import com.lvr.livecircle.R;
import com.lvr.livecircle.base.BaseFragment;

/**
 * Created by lvr on 2017/2/6.
 */

public class FindFragment extends BaseFragment {
    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_find;
    }

    @Override
    protected void initView() {

    }
}
