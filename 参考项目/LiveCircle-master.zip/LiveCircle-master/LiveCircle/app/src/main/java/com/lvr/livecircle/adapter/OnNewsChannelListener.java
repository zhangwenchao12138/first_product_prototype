package com.lvr.livecircle.adapter;

import com.lvr.livecircle.news.model.bean.NewsChannelTable;

/**
 * Created by lvr on 2017/2/11.
 */

public interface OnNewsChannelListener {
    void changeChannelListener(NewsChannelTable newsChannelTable);
}
