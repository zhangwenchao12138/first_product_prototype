package com.lvr.livecircle.nearby;

import com.lvr.livecircle.R;
import com.lvr.livecircle.base.BaseFragment;

/**
 * Created by lvr on 2017/2/6.
 */

public class NearByFragment extends BaseFragment {
    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_nearby;
    }



    @Override
    protected void initView() {

    }
}
