package com.lvr.livecircle.news.presenter;

/**
 * Created by lvr on 2017/2/11.
 */

public interface NewsDetailPresenter {
    void requestDetailNews(String postId);
}
