package com.lvr.livecircle.recommend;

import com.lvr.livecircle.R;
import com.lvr.livecircle.base.BaseFragment;

/**
 * Created by lvr on 2017/2/6.
 */

public class RecommendFragment extends BaseFragment {
    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_recommend;
    }



    @Override
    protected void initView() {

    }
}
