package com.lvr.livecircle.meitu.presenter;

/**
 * Created by lvr on 2017/2/20.
 */

public interface PhotoPresenter {
    void requestPhotoList(int size,int page);
}
