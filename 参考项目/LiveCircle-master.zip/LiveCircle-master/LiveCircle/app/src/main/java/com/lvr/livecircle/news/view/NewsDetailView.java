package com.lvr.livecircle.news.view;

import com.lvr.livecircle.news.model.bean.NewsDetail;

/**
 * Created by lvr on 2017/2/11.
 */

public interface NewsDetailView {
    void returnNewsDetail(NewsDetail detail);
}
