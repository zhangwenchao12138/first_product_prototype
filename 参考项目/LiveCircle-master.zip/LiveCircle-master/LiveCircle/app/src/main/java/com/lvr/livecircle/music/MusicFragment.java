package com.lvr.livecircle.music;

import com.lvr.livecircle.R;
import com.lvr.livecircle.base.BaseFragment;

/**
 * Created by lvr on 2017/2/6.
 */

public class MusicFragment extends BaseFragment {
    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_music;
    }


    @Override
    protected void initView() {

    }
}
